# data_ingestion
This library was created as part of the EDSA project on creating Pyhton package that read datasets from various sources, SQL databases and web csv.

## Building this package locally
'pyhton setup.py sdist'

